package item

import (
	"fmt"
	"log"
	"net/http"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
	"github.com/osalomon89/go-basics/internal/core/domain"
)

type handler struct {
	core        CoreService
	itemService ItemService
}

// CreateItem crea un nuevo item.
func (h *handler) CreateItem(c *gin.Context) {
	var newItem domain.Item

	if err := c.ShouldBindJSON(&newItem); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	item, err := h.itemService.AddItem(c.Request.Context(), newItem)
	if err != nil {
		log.Printf("error inserting item: %v", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusCreated, item)
}

func (h *handler) GetItem(c *gin.Context) {
	idStr := c.Param("id")
	id, err := strconv.ParseUint(idStr, 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}

	item, err := h.itemService.ReadItem(c.Request.Context(), uint(id))
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	if item == nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "item not found"})
		return
	}

	c.JSON(http.StatusOK, item)
}

func (h *handler) ListItems(c *gin.Context) {
	ctx := c.Request.Context()
	limitParam := c.Query("limit")
	cursorParam := c.Query("cursor")

	limit, err := strconv.Atoi(limitParam)
	if err != nil || limit <= 0 {
		limit = 10
	}

	var searchAfter []any
	if cursorParam != "" {
		searchAfter = parseCursor(cursorParam)
	}

	items, newCursor, err := h.itemService.GetAllItems(ctx, limit, searchAfter)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	response := struct {
		Items  []domain.Item `json:"items"`
		Cursor string        `json:"cursor,omitempty"`
	}{
		Items: items,
	}

	if newCursor != nil {
		response.Cursor = encodeCursor(newCursor)
	}

	c.JSON(http.StatusOK, response)
}

func (h *handler) UpdateItem(c *gin.Context) {
	var updatedItem domain.Item

	if err := c.ShouldBindJSON(&updatedItem); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	idStr := c.Param("id")
	id, err := strconv.ParseUint(idStr, 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}
	updatedItem.ID = uint(id)

	result, err := h.itemService.UpdateItem(c.Request.Context(), updatedItem)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	if result == nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "item not found"})
		return
	}

	c.JSON(http.StatusOK, result)
}

func parseCursor(cursor string) []any {
	parts := strings.Split(cursor, ",")
	parsed := make([]any, len(parts))
	for i, part := range parts {
		if num, err := strconv.ParseFloat(part, 64); err == nil {
			parsed[i] = num
		} else {
			parsed[i] = part
		}
	}
	return parsed
}

func encodeCursor(cursor []any) string {
	parts := make([]string, len(cursor))
	for i, part := range cursor {
		switch v := part.(type) {
		case float64:
			parts[i] = strconv.FormatFloat(v, 'f', -1, 64)
		default:
			parts[i] = fmt.Sprintf("%v", part)
		}
	}
	return strings.Join(parts, ",")
}
