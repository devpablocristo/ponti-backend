package item

import (
	"context"

	"github.com/osalomon89/go-basics/internal/core/domain"
)

type Service interface {
	ListItem(context.Context, int, []any) ([]domain.Item, []any, error)
	GetItem(context.Context, string) (*domain.Item, error)
	CreateIteam(context.Context, *domain.Item) error
	UpdateIteam(context.Context, *domain.Item) error
	DeleteItem(context.Context, string) error
}

type Repository interface {
	ListItem(context.Context, int, []any) ([]domain.Item, []any, error)
	GetItem(context.Context, string) (*domain.Item, error)
	CreateIteam(context.Context, *domain.Item) error
	UpdateIteam(context.Context, *domain.Item) error
	DeleteItem(context.Context, string) error
}

type ProviderClient interface {
	GetProvider(id int) (domain.Provider, error)
}
