package item

import (
	"context"
	"fmt"
	"time"

	"github.com/osalomon89/go-basics/internal/core/domain"
)

type service struct {
	repo           Repository
	providerClient ProviderClient
}

// NewUseCases crea una nueva instancia de service.
func NewUseCases(r mysql, p ProviderClient) Service {
	return &service{
		r:              mysql,
		providerClient: p,
	}
}
func (s *service) CreateItem(it *domain.Item) error {
	now := time.Now()
	it.CreatedAt = now
	it.UpdatedAt = now

	if err := s.repo.SaveItem(it); err != nil {
		return fmt.Errorf("error saving item in MySQL: %w", err)
	}
	return nil
}

func (s *service) ListItems() ([]domain.Items, error) {
	Items, err := s.repo.ListItems()
	if err != nil {
		return nil, fmt.Errorf("error listing items from MySQL: %w", err)
	}

	return Items, nil
}

func (s *service) AddItem(ctx context.Context, item domain.Item) (*domain.Item, error) {
	if item.Title == "" {
		return nil, fmt.Errorf("title cannot be empty")
	}

	if item.Code == "" {
		return nil, fmt.Errorf("code cannot be empty")
	}

	if item.Price <= 0 {
		return nil, fmt.Errorf("price must be greater than zero")
	}

	if item.Stock > 0 {
		item.Available = true
	}

	if err := s.repo.AddItem(ctx, &item); err != nil {
		return nil, fmt.Errorf("error in repository: %w", err)
	}

	return &item, nil
}

func (s *service) GetItem(ctx context.Context, id string) *domain.Item {
	item, err := s.repo.ReadItem(ctx, id)
	if err != nil {
		return nil
	}

	return item
}

func (s *service) UpdateItem(ctx context.Context, updatedItem *domain.Item) error {
	item, err := s.repo.Update(ctx, updatedItem)
	if err != nil {
		return nil
	}
	return item
}
