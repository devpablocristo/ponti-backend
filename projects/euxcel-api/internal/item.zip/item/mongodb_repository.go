package item

import (
	"context"
	"time"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
)

type mongoDbRepository struct {
	db *mongo.Database
}

func NewMongoDbRepository(db *mongo.Database) Repository {
	return &mongoDbRepository{
		db: db,
	}
}

func (r *mongoDbRepository) SaveItem(it *Item) error {
	it.CreatedAt = time.Now()
	it.UpdatedAt = time.Now()
	_, err := r.db.Collection("items").InsertOne(context.TODO(), it)
	return err
}

func (r *mongoDbRepository) ListItems() (MapRepo, error) {
	cursor, err := r.db.Collection("items").Find(context.TODO(), bson.D{})
	if err != nil {
		return nil, err
	}
	defer cursor.Close(context.TODO())

	items := make(MapRepo)
	for cursor.Next(context.TODO()) {
		var it Item
		if err := cursor.Decode(&it); err != nil {
			return nil, err
		}
		items[it.ID] = it
	}

	return items, nil
}
