package domain

import "time"

const (
	ItemTypeOwn         = "OWN"
	ItemTypeSeller      = "SELLER"
	StatusAll           = "ALL"
	StatusActive        = "ACTIVE"
	StatusInactive      = "INACTIVE"
	LeaderLevelBasic    = "BASIC"
	LeaderLevelGold     = "GOLD"
	LeaderLevelPlatinum = "PLATINUM"
)

type Photo struct {
	ID        uint
	Path      string
	ItemID    uint
	CreatedAt time.Time
	UpdatedAt time.Time
}

type Provider struct {
	Code string
	Name string
}

type Item struct {
	ID          uint
	Code        string
	ProviderID  int
	Title       string
	Description string
	Price       float64
	Stock       int
	Available   bool
	Categories  string
	Provider    Provider
	ItemType    string
	Leader      bool
	LeaderLevel string
	Status      string
	Photos      []Photo
	CreatedAt   time.Time
	UpdatedAt   time.Time
}

func (item *Item) SetStatus() {
	if item.Stock > 0 {
		item.Status = StatusActive
	} else {
		item.Status = StatusInactive
	}
}
