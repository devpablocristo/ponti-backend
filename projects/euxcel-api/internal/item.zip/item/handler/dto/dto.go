package dto

import "time"

type CreateItemDTO struct {
	Code        string  `json:"code" binding:"required"`
	ProviderID  int     `json:"provider_id" binding:"required"`
	Title       string  `json:"title" binding:"required"`
	Description string  `json:"description"`
	Price       float64 `json:"price" binding:"required,gt=0"`
	Stock       int     `json:"stock" binding:"required,gte=0"`
	Available   bool    `json:"available"`
	Categories  string  `json:"categories" binding:"required"`
	ItemType    string  `json:"item_type,omitempty"`
	Leader      bool    `json:"leader,omitempty"`
	LeaderLevel string  `json:"leader_level,omitempty"`
}

type UpdateItemDTO struct {
	Title       *string  `json:"title,omitempty"`
	Description *string  `json:"description,omitempty"`
	Price       *float64 `json:"price,omitempty" binding:"omitempty,gt=0"`
	Stock       *int     `json:"stock,omitempty" binding:"omitempty,gte=0"`
	Available   *bool    `json:"available,omitempty"`
	Categories  *string  `json:"categories,omitempty"`
	ItemType    *string  `json:"item_type,omitempty"`
	Leader      *bool    `json:"leader,omitempty"`
	LeaderLevel *string  `json:"leader_level,omitempty"`
}

type ItemResponseDTO struct {
	ID          uint       `json:"id"`
	Code        string     `json:"code"`
	ProviderID  int        `json:"provider_id"`
	Title       string     `json:"title"`
	Description string     `json:"description"`
	Price       float64    `json:"price"`
	Stock       int        `json:"stock"`
	Available   bool       `json:"available"`
	Categories  string     `json:"categories"`
	ItemType    string     `json:"item_type,omitempty"`
	Leader      bool       `json:"leader,omitempty"`
	LeaderLevel string     `json:"leader_level,omitempty"`
	Status      string     `json:"status"`
	Photos      []PhotoDTO `json:"photos,omitempty"`
	CreatedAt   time.Time  `json:"created_at"`
	UpdatedAt   time.Time  `json:"updated_at"`
}

type PhotoDTO struct {
	ID        uint      `json:"id"`
	Path      string    `json:"path"`
	ItemID    uint      `json:"item_id"`
	CreatedAt time.Time `json:"created_at"`
	UpdatedAt time.Time `json:"updated_at"`
}
